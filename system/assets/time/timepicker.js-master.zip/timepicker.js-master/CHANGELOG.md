# Changelog

## [3.0.0] - 2020-07-24

### Added
- A bunch of new themes.

### Changed
- No longer needs to load a separate CSS file.
- (breaking change) No longer accept an array of elements.